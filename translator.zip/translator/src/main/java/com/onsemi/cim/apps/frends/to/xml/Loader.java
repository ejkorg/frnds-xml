package com.onsemi.cim.apps.frends.to.xml;

import com.onsemi.cim.apps.frends.to.xml.data.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;

/**
 *
 * @author fg7x8c
 */
public class Loader {
    
    private final BufferedReader br;
    private Data data;
    
    private final String EQUALS_DELIMITER = "=";
    private final String COMMA_DELIMITER = ",";

    private final String ITEM_NAME = "ITEM_NAME";
    private final String SPEC_MAX = "SPEC_MAX";
    private final String SPEC_MIN = "SPEC_MIN";
    private final String UNIT = "UNIT";

    public Loader(InputStream inStream) {
        this.br = new BufferedReader(new InputStreamReader(inStream));
    }
    
    public Data loadFile() throws IOException, ParseException {
        data = new Data();
        loadMetadata();
        loadCategory();
        loadMeasurements();
        return data;
    }
    
    private void loadMetadata() throws IOException, ParseException{
        String line;
        int delimiterIndex;

        while (!(line = br.readLine()).startsWith("HEADER_END")) {

            delimiterIndex = line.indexOf(EQUALS_DELIMITER);

            if (delimiterIndex != -1) {
                data.getMetadata().put(line.substring(0, delimiterIndex), ((delimiterIndex + 1) <= line.length()) ? line.substring(delimiterIndex + 1) : null);
            }
        }
    }
        
    private void loadCategory() throws IOException{
        
        String line;
        
        while (!(line = br.readLine()).startsWith("CATEGORY_END")) {
            
            int firstComma = line.indexOf(COMMA_DELIMITER);
            int equals = line.indexOf(EQUALS_DELIMITER);
            int secondComma = line.lastIndexOf(COMMA_DELIMITER);

            if (firstComma != -1 && equals != -1 && secondComma != -1) {
                Short x = Short.parseShort(line.substring(0, firstComma).trim());
                Short y = Short.parseShort(line.substring(firstComma + 1, equals).trim());
                Short hBin = Short.parseShort(line.substring(secondComma + 1).trim());
                Short sBin = Short.parseShort(line.substring(equals + 1, secondComma).trim());
                
                data.getChips().put(new Coords(x, y), new Chip(hBin, sBin));
                
                //increase count for hbin
                if(!data.gethBins().containsKey(hBin)) {
                    data.gethBins().put(hBin, (short)1);
                } else {
                    Short currentCount = data.gethBins().get(hBin);
                    data.gethBins().put(hBin, (short) (currentCount + 1));
                }
                
                //increase count for sbin
                if(!data.getsBins().containsKey(sBin)) {
                    data.getsBins().put(sBin, (short)1);
                } else {
                    Short currentCount = data.getsBins().get(sBin);
                    data.getsBins().put(sBin, (short) (currentCount + 1));
                }
            }
        }
    }
    
    private void loadMeasurements() throws IOException {
        
        String line = null;
        short testNum = 1;
               
        do { 
            data.getTests().put(testNum, loadTestInfo(line));
            loadTestResults(testNum);
            testNum++;
        } while (!(line = br.readLine()).startsWith("LOG_END"));
    }

    private Test loadTestInfo(String lastLine) throws IOException {
        
        String line;
        
        String testname = null;
        String lowSpecLimit = null;
        String highSpecLimit = null;
        String unit = null;
        
        if(lastLine != null && lastLine.startsWith(ITEM_NAME) && lastLine.contains(EQUALS_DELIMITER)){
            testname = lastLine.substring(lastLine.indexOf(EQUALS_DELIMITER) + 1);
        }
        
        while (!(line = br.readLine()).startsWith("SPEC_END")) {
            if(line != null && line.contains(EQUALS_DELIMITER)){
                if (line.startsWith(ITEM_NAME)){
                    testname = line.substring(line.indexOf(EQUALS_DELIMITER) + 1);
                } else if (line.startsWith(SPEC_MAX)) {
                    highSpecLimit = line.substring(line.indexOf(EQUALS_DELIMITER) + 1).trim();
                } else if (line.startsWith(SPEC_MIN)) {
                    lowSpecLimit = line.substring(line.indexOf(EQUALS_DELIMITER) + 1).trim();
                } else if (line.startsWith(UNIT)) {
                    unit = line.substring(line.indexOf(EQUALS_DELIMITER) + 1).trim();
                }     
            }
        }

        return new Test(testname, lowSpecLimit, highSpecLimit, unit);
    }
    
    private void loadTestResults(short testNum) throws IOException {
        
        String line;
        Short execCount = 0;
        
        while (!(line = br.readLine()).startsWith("ITEM_END")) {
            int firstComma = line.indexOf(COMMA_DELIMITER);
            int equals = line.indexOf(EQUALS_DELIMITER);
            
            if (firstComma != -1 && equals != -1) {
                Short x = Short.parseShort(line.substring(0, firstComma).trim());
                Short y = Short.parseShort(line.substring(firstComma + 1, equals).trim());
                String result = line.substring(equals + 1).trim();
                data.getChips().get(new Coords(x, y)).getTestResults().put(testNum, result);
                execCount++;
            }
        }
        data.getTests().get(testNum).setExecCount(execCount);
    }
    
}
